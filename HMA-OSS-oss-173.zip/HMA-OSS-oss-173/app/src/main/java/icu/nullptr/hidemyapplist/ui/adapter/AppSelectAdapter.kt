package icu.nullptr.hidemyapplist.ui.adapter

import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import icu.nullptr.hidemyapplist.common.CollectionUtils.sync
import icu.nullptr.hidemyapplist.service.PrefManager
import icu.nullptr.hidemyapplist.ui.util.get
import icu.nullptr.hidemyapplist.ui.view.AppItemView
import icu.nullptr.hidemyapplist.util.PackageHelper
import kotlinx.coroutines.runBlocking
import org.frknkrc44.hma_oss.BuildConfig

abstract class AppSelectAdapter(
    private val hideMyself: Boolean,
    private val firstFilter: ((String) -> Boolean)? = null,
) : RecyclerView.Adapter<AppSelectAdapter.ViewHolder>(), Filterable {

    abstract class ViewHolder(view: AppItemView) : RecyclerView.ViewHolder(view) {
        abstract fun bind(packageName: String)
    }

    private inner class AppFilter : Filter() {
        override fun performFiltering(constraint: CharSequence): FilterResults {
            return runBlocking {
                val constraintLowered = constraint.toString().trim().lowercase()
                val filteredList = PackageHelper.appList.get().filter {
                    if (firstFilter?.invoke(it) == false) return@filter false
                    if (!PrefManager.appFilter_showSystem && PackageHelper.isSystem(it)) return@filter false
                    if (it == BuildConfig.APPLICATION_ID && hideMyself) return@filter false
                    val label = PackageHelper.loadAppLabel(it)
                    label.lowercase().contains(constraintLowered) || it.lowercase().contains(constraintLowered)
                }

                FilterResults().also { it.values = filteredList }
            }
        }

        @Suppress("UNCHECKED_CAST", "NotifyDataSetChanged")
        override fun publishResults(constraint: CharSequence, results: FilterResults) {
            val elements = results.values as? List<String> ?: return
            filteredList.sync(elements)
            notifyDataSetChanged()
        }
    }

    private val mFilter = AppFilter()

    protected val filteredList: MutableList<String> = mutableListOf()

    override fun getItemCount() = filteredList.size

    override fun getItemId(position: Int) = filteredList[position].hashCode().toLong()

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(filteredList[position])

    override fun getFilter(): Filter = mFilter
}
