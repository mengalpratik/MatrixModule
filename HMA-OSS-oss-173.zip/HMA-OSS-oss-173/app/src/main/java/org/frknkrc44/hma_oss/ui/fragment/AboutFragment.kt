package org.frknkrc44.hma_oss.ui.fragment

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.annotation.DrawableRes
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.transition.AutoTransition
import androidx.transition.TransitionManager
import coil3.load
import coil3.request.crossfade
import coil3.request.placeholder
import coil3.request.transformations
import coil3.transform.CircleCropTransformation
import dev.androidbroadcast.vbpd.viewBinding
import icu.nullptr.hidemyapplist.common.Constants
import icu.nullptr.hidemyapplist.data.AppConstants.allAppIcons
import icu.nullptr.hidemyapplist.service.PrefManager
import icu.nullptr.hidemyapplist.ui.util.AccessibilityUtils
import icu.nullptr.hidemyapplist.ui.util.ThemeUtils.attrDrawable
import icu.nullptr.hidemyapplist.ui.util.ThemeUtils.homeItemBackgroundColor
import icu.nullptr.hidemyapplist.ui.util.dpToPx
import icu.nullptr.hidemyapplist.ui.util.navController
import icu.nullptr.hidemyapplist.ui.util.setEdge2EdgeFlags
import icu.nullptr.hidemyapplist.util.PackageHelper.findEnabledAppComponent
import org.frknkrc44.hma_oss.R
import org.frknkrc44.hma_oss.common.BuildConfig
import org.frknkrc44.hma_oss.databinding.FragmentAboutBinding
import org.frknkrc44.hma_oss.databinding.FragmentAboutListItemBinding
import org.json.JSONObject

@Suppress("DEPRECATION")
class AboutFragment : Fragment(R.layout.fragment_about) {
    private val binding by viewBinding(FragmentAboutBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setEdge2EdgeFlags(binding.root, bottom = 0) { _, _, _, bottom ->
            binding.bottomPadding.minimumHeight = bottom
        }

        val tint = ColorStateList.valueOf(homeItemBackgroundColor())

        if (!AccessibilityUtils.isAnimationEnabled(requireContext().contentResolver)) {
            with(binding.aboutScroll) {
                overScrollMode = View.OVER_SCROLL_NEVER
            }
        }

        with(binding.aboutHeader) {
            with(backButton.parent as View) {
                setOnClickListener { navController.navigateUp()  }
                backgroundTintList = tint
            }

            val activityName = findEnabledAppComponent(requireContext())
            appIcon.setImageResource(
                activityName?.let {
                    allAppIcons.firstOrNull { it.second == activityName.className }?.first
                } ?: R.mipmap.ic_launcher
            )

            appName.setText(R.string.app_name)
            appVersion.text = BuildConfig.APP_VERSION_NAME

            if (PrefManager.systemWallpaper) {
                linkGithub.background.alpha = 0xAA
                linkTelegram.background.alpha = 0xAA
            }

            setOnClickUrl(linkGithub, "https://github.com/frknkrc44/HMA-OSS")
            setOnClickUrl(linkTelegram, "https://t.me/aerathfuns")

            appInfoTop.backgroundTintList = tint
            (appName.parent as View).backgroundTintList = tint
        }

        with(binding.aboutDescription) {
            contentTitle.setText(R.string.title_about)
            contentDescription.setText(R.string.about_description)
            contentDescription.backgroundTintList = tint
        }

        with(binding.aboutForkDescription) {
            contentTitle.setText(R.string.title_about_fork)
            contentDescription.setText(R.string.about_fork_description)
            contentDescription.backgroundTintList = tint
        }

        with(binding.listDeveloper) {
            backgroundTintList = tint
            clipToOutline = true
        }

        with(binding.devHeader) {
            background = LayerDrawable(arrayOf(
                GradientDrawable().apply {
                    setColor(0)
                    cornerRadius = 24.dpToPx
                },
                attrDrawable(android.R.attr.selectableItemBackground),
            ))
            clipToOutline = true

            setOnClickListener {
                if (binding.listHma.isVisible) {
                    binding.expandDevs.animate().rotation(0.0f).start()
                } else {
                    TransitionManager.beginDelayedTransition(binding.listDeveloper, AutoTransition())
                    binding.expandDevs.animate().rotation(180.0f).start()
                }

                binding.listHma.isVisible = !binding.listHma.isVisible
            }
        }

        // HMA-OSS devs
        with(binding.listHmaOss) {
            addDevItem(this, R.drawable.cont_fk, "frknkrc44", "HMA-OSS Developer", "https://github.com/frknkrc44")
            addDevItem(this, R.drawable.cont_oukaromf, "OukaroMF", "HMA-OSS Alt Icon Designer", "https://github.com/OukaroMF")
            addDevItem(this, R.drawable.cont_chunqiu, "longze", "HMA-OSS Contributor", null)
        }

        // Original HMA devs
        with(binding.listHma) {
            addDevItem(this, R.drawable.cont_nullptr, "nullptr", "HMA Developer", "https://github.com/Dr-TSNG")
            addDevItem(this, R.drawable.cont_k, "Ketal", "HMA Collaborator", "https://github.com/keta1")
            addDevItem(this, R.drawable.cont_aviraxp, "aviraxp", "HMA Collaborator", "https://github.com/aviraxp")
            addDevItem(this, R.drawable.cont_icon_designer, "辉少菌", "HMA Icon Designer", "http://www.coolapk.com/u/1560270")
            addDevItem(this, R.drawable.cont_cpp_master,  "LoveSy", "HMA Idea Provider", "https://github.com/yujincheng08")
        }

        with(binding.listTranslator) {
            backgroundTintList = tint
            clipToOutline = true

            val jsonObj = JSONObject(String(requireContext().assets.open("translators.json").readBytes()))
            val jsonKeys = jsonObj.keys().asSequence().sortedWith { a, b -> a.lowercase().compareTo(b.lowercase()) }
            for (name in jsonKeys) {
                val avatarUrl = jsonObj.getString(name)
                addTranslatorItem(this, avatarUrl, name)
            }
        }

        with(binding.listOpenSource) {
            backgroundTintList = tint
            clipToOutline = true

            addLibraryItem(this, "ZygoteLoader (fork)", "MIT License", "https://github.com/aerath-stuff/ZygoteLoader")
            addLibraryItem(this, "Coil", "Apache-2.0 License", "https://github.com/coil-kt/coil")
        }
    }

    fun addDevItem(layout: LinearLayout, @DrawableRes avatarResId: Int, name: String, desc: String, url: String?) {
        val newLayout = FragmentAboutListItemBinding.inflate(layoutInflater)
        setOnClickUrl(newLayout.root, url)

        newLayout.aboutPersonIcon.setImageDrawable(RoundedBitmapDrawableFactory.create(
            resources,
            BitmapFactory.decodeResource(resources, avatarResId)
        ).apply {
            isCircular = true
        })

        newLayout.text1.text = name
        newLayout.text2.text = desc
        layout.addView(newLayout.root)
    }

    fun addLibraryItem(layout: LinearLayout, name: String, desc: String, url: String) {
        val newLayout = FragmentAboutListItemBinding.inflate(layoutInflater)
        setOnClickUrl(newLayout.root, url)

        newLayout.aboutPersonIcon.isVisible = false
        newLayout.text1.text = name
        newLayout.text2.text = desc
        layout.addView(newLayout.root)
    }

    fun addTranslatorItem(layout: LinearLayout, avatarUrl: String, name: String) {
        val newLayout = FragmentAboutListItemBinding.inflate(layoutInflater)

        if (PrefManager.enableInternet == Constants.ENABLE_INTERNET_ON) {
            newLayout.aboutPersonIcon.load(
                avatarUrl,
                builder = {
                    crossfade(true)
                    placeholder(R.drawable.outline_info_24)
                    transformations(CircleCropTransformation())
                }
            )
        } else {
            newLayout.aboutPersonIcon.isVisible = false
        }

        newLayout.text1.text = name
        newLayout.text2.visibility = View.GONE
        layout.addView(newLayout.root)
    }

    fun setOnClickUrl(view: View, url: String?) {
        if (url == null) return

        view.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = url.toUri()
            startActivity(intent)
        }
    }
}
