package org.frknkrc44.hma_oss.zygote.util

@Suppress("SpellCheckingInspection")
object ZygoteConstants {
    const val SYSTEM_SERVER_CLASS = "com.android.server.SystemServer"
    const val RUNTIME_INIT_CLASS = "com.android.internal.os.RuntimeInit"
    const val ZYGOTE_INIT_CLASS = "com.android.internal.os.ZygoteInit"
    const val COMPUTER_ENGINE_CLASS = "com.android.server.pm.ComputerEngine"
    const val PACKAGE_MANAGER_SERVICE_CLASS = "com.android.server.pm.PackageManagerService"
    const val PMS_COMPUTER_TRACKER_CLASS = $$"com.android.server.pm.PackageManagerService$ComputerTracker"
    const val PMS_COMPUTER_ENGINE_CLASS = $$"com.android.server.pm.PackageManagerService$ComputerEngine"
    const val APPS_FILTER_CLASS = "com.android.server.pm.AppsFilter"
    const val APPS_FILTER_IMPL_CLASS = "com.android.server.pm.AppsFilterImpl"
    const val STORAGE_MANAGER_SERVICE_CLASS = "com.android.server.StorageManagerService"
    const val STORAGE_MANAGER_SERVICE_LIFECYCLE_CLASS = $$"com.android.server.StorageManagerService$Lifecycle"
    const val ACCESSIBILITY_SERVICE_CLASS = "com.android.server.accessibility.AccessibilityManagerService"
    const val CONTENT_PROVIDER_TRANSPORT_CLASS = $$"android.content.ContentProvider$Transport"
    const val IMM_SERVICE_CLASS = "com.android.server.inputmethod.InputMethodManagerService"
    const val IMM_IMPL_CLASS = "com.android.server.inputmethod.IInputMethodManagerImpl"
    const val ACTIVITY_STARTER_CLASS = "com.android.server.wm.ActivityStarter"
    const val ACTIVITY_TASK_SUPERVISOR_CLASS = "com.android.server.wm.ActivityTaskSupervisor"
    const val ACTIVITY_STACK_SUPERVISOR_CLASS = "com.android.server.wm.ActivityStackSupervisor"
    const val ZYGOTE_PROCESS_CLASS = "android.os.ZygoteProcess"
    const val NATIVE_ZYGOTE_PROCESS_CLASS = "android.os.NativeZygoteProcess"
    const val PROCESS_LIST_CLASS = "com.android.server.am.ProcessList"
    const val PROCESS_RECORD_INTERNAL_CLASS = "com.android.server.am.psc.ProcessRecordInternal"
    const val BROADCAST_CONTROLLER_CLASS = "com.android.server.am.BroadcastController"
    const val ACTIVITY_MANAGER_SERVICE_CLASS = "com.android.server.am.ActivityManagerService"
    const val BROADCAST_HELPER_CLASS = "com.android.server.pm.BroadcastHelper"
    const val PACKAGE_MONITOR_CLASS = "com.android.internal.content.PackageMonitor"
    const val SERVICE_RECORD_CLASS = "com.android.server.am.ServiceRecord"
    const val BROADCAST_QUEUE_CLASS = "com.android.server.am.BroadcastQueue"
    const val BROADCAST_QUEUE_IMPL_CLASS = "com.android.server.am.BroadcastQueueImpl"
    const val BROADCAST_PROCESS_QUEUE_CLASS = "com.android.server.am.BroadcastProcessQueue"

    const val CONSTRUCTOR_METHOD_NAME = "<init>"

    const val PACKAGE_MANAGER_SERVICE = "package"
    const val PACKAGE_MANAGER_NATIVE_SERVICE = "package_native"
    const val WEBVIEW_UPDATE_SERVICE = "webviewupdate"

    const val WEBVIEW_PROVIDER_KEY = "webview_provider"

    const val ACTION_USB_STATE = "android.hardware.usb.action.USB_STATE"
    const val USB_FUNCTION_ADB = "adb"

    const val GBOARD_PACKAGE_NAME = "com.google.android.inputmethod.latin"
    const val GBOARD_CLASS_NAME = "com.android.inputmethod.latin.LatinIME"
}
